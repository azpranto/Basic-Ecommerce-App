package com.example.ecommerce.controllers;

import com.example.ecommerce.services.CustomerService;
import com.example.ecommerce.services.OrderService;
import com.example.ecommerce.services.ProductService;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class DashboardController {
    private final ProductService productService = new ProductService();
    private final CustomerService customerService = new CustomerService();
    private final OrderService orderService = new OrderService();

    @FXML private Label productsCount;
    @FXML private Label customersCount;
    @FXML private Label pendingOrdersCount;

    @FXML
    public void initialize() {
        productsCount.setText(String.valueOf(productService.list("").size()));
        customersCount.setText(String.valueOf(customerService.list("").size()));
        pendingOrdersCount.setText(String.valueOf(orderService.countPending()));
    }
}

